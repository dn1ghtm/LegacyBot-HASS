require('dotenv').config();
const { Client, GatewayIntentBits, EmbedBuilder, REST, Routes, SlashCommandBuilder, ActivityType, ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, Events, GuildScheduledEventEntityType, GuildScheduledEventPrivacyLevel, StringSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const SETTINGS_FILE = 'bot_settings.json';
const { parse } = require('date-fns');
const chrono = require('chrono-node');

// Load settings from file
function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    }
  } catch (e) { console.error('Failed to load settings:', e); }
  return {};
}

// Save settings to file
function saveSettings(settings) {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  } catch (e) { console.error('Failed to save settings:', e); }
}

// Save settings per guild
function saveGuildSetting(guildId, key, value) {
  if (!botSettings.guilds) botSettings.guilds = {};
  if (!botSettings.guilds[guildId]) botSettings.guilds[guildId] = {};
  botSettings.guilds[guildId][key] = value;
  saveSettings(botSettings);
}
function getGuildSetting(guildId, key) {
  return botSettings.guilds && botSettings.guilds[guildId] && botSettings.guilds[guildId][key];
}

let botSettings = loadSettings();

// Create a new client instance
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds
  ]
});

// Create slash commands
const commands = [
  new SlashCommandBuilder()
    .setName('value')
    .setDescription('Calculate player value based on stats')
    .addIntegerOption(option => option.setName('tackles').setDescription('Number of tackles').setRequired(true))
    .addIntegerOption(option => option.setName('inters').setDescription('Number of interceptions').setRequired(true))
    .addIntegerOption(option => option.setName('saves').setDescription('Number of saves').setRequired(true))
    .addIntegerOption(option => option.setName('goals').setDescription('Number of goals').setRequired(true))
    .addIntegerOption(option => option.setName('passes').setDescription('Number of passes').setRequired(true))
    .addIntegerOption(option => option.setName('assists').setDescription('Number of assists').setRequired(true))
    .addIntegerOption(option => option.setName('dribbles').setDescription('Number of dribbles').setRequired(true))
    .addIntegerOption(option => option.setName('shots').setDescription('Number of shots').setRequired(true))
    .addIntegerOption(option => option.setName('games').setDescription('Number of games').setRequired(true)),
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Display help information about the bot')
].map(command => command.toJSON());

// Add event creation command (now only asks for title and description)
commands.splice(commands.findIndex(cmd => cmd.name === 'event'), 1);
commands.push(
  new SlashCommandBuilder()
    .setName('event')
    .setDescription('Create a training event')
    .addStringOption(option => option.setName('title').setDescription('Event title').setRequired(true))
    .addStringOption(option => option.setName('description').setDescription('Event description/details').setRequired(false))
);

// Add settings command
commands.push(
  new SlashCommandBuilder()
    .setName('settings')
    .setDescription('Configure bot settings')
    .addSubcommand(sub =>
      sub.setName('set-coaches-channel')
        .setDescription('Set the private coaches channel')
        .addChannelOption(opt =>
          opt.setName('channel').setDescription('Coaches channel').setRequired(true)
        )
    )
);

// Define the weights for each stat
const STAT_WEIGHTS = {
  tackles: 200,
  inters: 100,
  saves: 500,
  goals: 600,
  passes: 250,
  assists: 400,
  dribbles: 100,
  shots: 300,
  games: 200
};

// --- Event RSVP Constants ---
const EVENT_BUTTONS = {
  GOING: 'event_going',
  MAYBE: 'event_maybe',
  CANT: 'event_cant',
};
const EVENT_MODAL = {
  CANT_REASON: 'cant_reason_modal',
  CANT_REASON_INPUT: 'cant_reason_input',
};
const EVENT_SELECT_TIME = 'event_select_time';
const EVENT_MODAL_TIME = 'event_modal_time';
const EVENT_MODAL_DATE_TIME = 'event_modal_date_time';

// --- RSVP State ---
const eventRSVPs = {}; // { [messageId]: { going: Set, maybe: Set, cant: Map<userId, reason> } }

// Helper: Parse 'when' string to a Date object (supports 'in a day', 'in a week', or direct date)
function parseWhenToDate(when) {
  const now = new Date();
  const lower = when.toLowerCase();
  if (lower === 'in a day') return new Date(now.getTime() + 24 * 60 * 60 * 1000);
  if (lower === 'in a week') return new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  // Try to parse as date string (e.g. 2024-06-10 18:00)
  const parsed = Date.parse(when);
  if (!isNaN(parsed)) return new Date(parsed);
  return null;
}

// Helper: Google Calendar event link
function googleCalendarLink({ title, description, start, end }) {
  const fmt = d => d.toISOString().replace(/[-:]|\.\d{3}/g, '').slice(0, 15) + 'Z';
  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: title,
    details: description || '',
    dates: `${fmt(start)}/${fmt(end)}`
  });
  return `https://www.google.com/calendar/render?${params.toString()}`;
}

// When the client is ready, run this code (only once)
client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}!`);
  
  try {
    // Register slash commands
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    
    console.log('Started refreshing application (/) commands.');
    
    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands },
    );
    
    console.log('Successfully reloaded application (/) commands.');
    
    // Set up alternating activities and status
    let activityIndex = 0;
    const activities = [
      { name: 'Rematch', type: ActivityType.Playing, status: 'online' }, // Playing Rematch
      { name: 'The Legacy League 🏆', type: ActivityType.Watching, status: 'online' }, // Watching Legacy League
      { name: 'Scrims', type: ActivityType.Streaming, url: 'https://www.twitch.tv/itsn1ghtm', status: 'dnd' } // Streaming Scrims
    ];
    
    // Update activity and status every 25 seconds
    setInterval(() => {
      const activity = activities[activityIndex];
      client.user.setPresence({
        activities: [{ name: activity.name, type: activity.type, url: activity.url }],
        status: activity.status
      });
      
      // Switch to the next activity
      activityIndex = (activityIndex + 1) % activities.length;
    }, 2500); // 25 seconds
    
    // Set initial activity and status
    const initialActivity = activities[0];
    client.user.setPresence({
      activities: [{ name: initialActivity.name, type: initialActivity.type }],
      status: initialActivity.status
    });
  } catch (error) {
    console.error('Error refreshing application commands:', error);
  }
});

// --- Event RSVP Handlers ---

// Listen for interactions (slash commands, buttons, modals)
client.on('interactionCreate', async (interaction) => {
  try {
    // --- SLASH COMMANDS ---
    if (interaction.isCommand()) {
      const { commandName } = interaction;

      if (commandName === 'value') {
        // Immediately acknowledge the interaction to prevent timeout
        try {
          // Defer the reply to prevent timeout
          await interaction.deferReply();
          
          // Get the stats from the options
          const stats = {
            tackles: interaction.options.getInteger('tackles'),
            inters: interaction.options.getInteger('inters'),
            saves: interaction.options.getInteger('saves'),
            goals: interaction.options.getInteger('goals'),
            passes: interaction.options.getInteger('passes'),
            assists: interaction.options.getInteger('assists'),
            dribbles: interaction.options.getInteger('dribbles'),
            shots: interaction.options.getInteger('shots'),
            games: interaction.options.getInteger('games')
          };

          // Calculate the player value
          const playerValue = calculatePlayerValue(stats);
          
          // Calculate contribution percentages for visualization
          const statContributions = {};
          let totalContribution = 0;
          
          for (const [stat, value] of Object.entries(stats)) {
            const contribution = value * STAT_WEIGHTS[stat];
            statContributions[stat] = contribution;
            totalContribution += contribution;
          }
          
          // Find the highest contributing stat for highlighting
          const highestStat = Object.entries(statContributions).reduce((a, b) => a[1] > b[1] ? a : b);
          const playerType = getPlayerType(statContributions);
          
          // Group stats by category
          const defensiveStats = {
            tackles: stats.tackles,
            inters: stats.inters,
            saves: stats.saves
          };
          
          const offensiveStats = {
            goals: stats.goals,
            shots: stats.shots,
            dribbles: stats.dribbles
          };
          
          const playmakerStats = {
            assists: stats.assists,
            passes: stats.passes,
            games: stats.games
          };
          
          // Format stat fields with contribution percentages
           const formatStatField = (statName, statValue, weight, contribution) => {
             return {
               name: formatStatName(statName),
               value: `**${statValue}**`,
               inline: true
             };
           };
          
          // Create defensive stat fields
          const defensiveFields = Object.entries(defensiveStats).map(([stat, value]) => 
            formatStatField(stat, value, STAT_WEIGHTS[stat], statContributions[stat])
          );
          
          // Create offensive stat fields
          const offensiveFields = Object.entries(offensiveStats).map(([stat, value]) => 
            formatStatField(stat, value, STAT_WEIGHTS[stat], statContributions[stat])
          );
          
          // Create playmaker stat fields
          const playmakerFields = Object.entries(playmakerStats).map(([stat, value]) => 
            formatStatField(stat, value, STAT_WEIGHTS[stat], statContributions[stat])
          );
          
          // Calculate category totals
          const defensiveTotal = Object.entries(defensiveStats).reduce((total, [stat, value]) => total + (value * STAT_WEIGHTS[stat]), 0);
          const offensiveTotal = Object.entries(offensiveStats).reduce((total, [stat, value]) => total + (value * STAT_WEIGHTS[stat]), 0);
          const playmakerTotal = Object.entries(playmakerStats).reduce((total, [stat, value]) => total + (value * STAT_WEIGHTS[stat]), 0);
          
          // Calculate percentages for visual representation
          const defensivePercent = Math.round((defensiveTotal / playerValue) * 100);
          const offensivePercent = Math.round((offensiveTotal / playerValue) * 100);
          const playmakerPercent = Math.round((playmakerTotal / playerValue) * 100);
          
          // Create visual bars for stat distribution with fixed width
          const createBar = (percent) => {
            const fullBlocks = Math.floor(percent / 10);
            let bar = '';
            for (let i = 0; i < 10; i++) {
              bar += i < fullBlocks ? '█' : '░';
            }
            return bar;
          };
          
          const defensiveBar = createBar(defensivePercent);
          const offensiveBar = createBar(offensivePercent);
          const playmakerBar = createBar(playmakerPercent);
          
          // Calculate per-game averages
          const gamesPlayed = stats.games || 1; // Prevent division by zero
          const avgValue = Math.round(playerValue / gamesPlayed);
          const avgGoals = (stats.goals / gamesPlayed).toFixed(2);
          const avgAssists = (stats.assists / gamesPlayed).toFixed(2);
          const avgTackles = (stats.tackles / gamesPlayed).toFixed(2);
          const avgInters = (stats.inters / gamesPlayed).toFixed(2);
          const avgSaves = (stats.saves / gamesPlayed).toFixed(2);
          const avgPasses = (stats.passes / gamesPlayed).toFixed(2);
          const avgDribbles = (stats.dribbles / gamesPlayed).toFixed(2);
          const avgShots = (stats.shots / gamesPlayed).toFixed(2);
          
          // Create a more compact embed for the response
          const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`⚽ ${interaction.user.username}'s Player Value Analysis`)
            .setDescription(`**$${playerValue.toLocaleString()}** | **${playerType}** | **$${avgValue.toLocaleString()}/Game**`)
            .addFields(
              // Category distribution with bars - aligned without monetary values
              { name: 'Stat Distribution', value: `🛡️ **${defensivePercent}%** ${defensiveBar}\n⚽ **${offensivePercent}%** ${offensiveBar}\n🔄 **${playmakerPercent}%** ${playmakerBar}`, inline: false },
              
              // Main stats in improved format
              { name: '🛡️ Defensive', value: `**Tackles:** ${stats.tackles}\n**Interceptions:** ${stats.inters}\n**Saves:** ${stats.saves}`, inline: true },
              { name: '⚽ Offensive', value: `**Goals:** ${stats.goals}\n**Shots:** ${stats.shots}\n**Dribbles:** ${stats.dribbles}`, inline: true },
              { name: '🔄 Playmaker', value: `**Assists:** ${stats.assists}\n**Passes:** ${stats.passes}\n**Games:** ${stats.games}`, inline: true },
              
              // Per game stats in improved format
              { name: 'Per Game Averages', value: `**Goals:** ${avgGoals} • **Assists:** ${avgAssists} • **Tackles:** ${avgTackles}
**Inters:** ${avgInters} • **Saves:** ${avgSaves} • **Passes:** ${avgPasses}
**Dribbles:** ${avgDribbles} • **Shots:** ${avgShots}`, inline: false }
            )
            .setFooter({ text: 'LL Value Bot | Advanced Player Analysis' })
            .setTimestamp();

          // Send the embed - handle different interaction states
          if (interaction.deferred) {
            await interaction.editReply({ embeds: [embed] });
          } else if (interaction.replied) {
            await interaction.followUp({ embeds: [embed] });
          } else {
            await interaction.reply({ embeds: [embed] });
          }
        } catch (error) {
          console.error('Error calculating player value:', error);
          // Check if the interaction has already been replied to
          if (interaction.replied) {
            await interaction.followUp({ content: 'An error occurred while calculating the player value.', ephemeral: true }).catch(console.error);
          } else if (interaction.deferred) {
            await interaction.editReply({ content: 'An error occurred while calculating the player value.' }).catch(console.error);
          } else {
            await interaction.reply({ content: 'An error occurred while calculating the player value.', ephemeral: true }).catch(console.error);
          }
        }
      } else if (commandName === 'help') {
        try {
          // Defer the reply to prevent timeout
          await interaction.deferReply();
          
          // Provide help information
          const helpEmbed = new EmbedBuilder()
              .setColor('#0099ff')
              .setTitle('⚽ Player Value Bot Help')
              .setDescription('Calculate player value and determine player type based on stats')
              .addFields(
                { name: '📊 Usage', value: '`/value` - Calculate player value with all required stats' },
                { name: '⚖️ Stat Weights', value: Object.entries(STAT_WEIGHTS).map(([stat, weight]) => `${formatStatName(stat)}: **$${weight}**`).join(' | ') },
                { name: '🏆 Player Types', value: '🛡️ Defensive | ⚽ Offensive | 🔄 Playmaker | ⚖️ Two-Way | 🧠 Def-Play | 🎯 Creative | 🌟 Complete' }
              )
              .setFooter({ text: 'Legacy League Player Value Calculator' })
              .setTimestamp();

          // Send the embed - handle different interaction states
          if (interaction.deferred) {
            await interaction.editReply({ embeds: [helpEmbed] });
          } else if (interaction.replied) {
            await interaction.followUp({ embeds: [helpEmbed] });
          } else {
            await interaction.reply({ embeds: [helpEmbed] });
          }
        } catch (error) {
          console.error('Error displaying help information:', error);
          // Check if the interaction has already been replied to
          if (interaction.replied) {
            await interaction.followUp({ content: 'An error occurred while displaying help information.', ephemeral: true }).catch(console.error);
          } else if (interaction.deferred) {
            await interaction.editReply({ content: 'An error occurred while displaying help information.' }).catch(console.error);
          } else {
            await interaction.reply({ content: 'An error occurred while displaying help information.', ephemeral: true }).catch(console.error);
          }
        }
      } else if (commandName === 'event') {
        if (!interaction.memberPermissions || !interaction.memberPermissions.has('Administrator')) {
          await interaction.reply({ content: '❌ Only server administrators/coaches can create events.', ephemeral: true });
          return;
        }
        const title = interaction.options.getString('title');
        const desc = interaction.options.getString('description') || '';
        // Show select menu for time
        const select = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(EVENT_SELECT_TIME)
            .setPlaceholder('Choose when the event will be')
            .addOptions([
              { label: 'In 1 hour', value: 'in 1 hour' },
              { label: 'Tonight (19:00)', value: 'tonight' },
              { label: 'Tomorrow (18:00)', value: 'tomorrow' },
              { label: 'In a week', value: 'in a week' },
              { label: 'Custom...', value: 'custom' }
            ])
        );
        await interaction.reply({ content: '🕒 When is the event?', components: [select], ephemeral: true });
        // Store temp event data in memory
        eventRSVPs[interaction.user.id] = { title, desc };
        return;
      } else if (commandName === 'settings') {
        // Only allow admins to use settings
        if (!interaction.memberPermissions || !interaction.memberPermissions.has('Administrator')) {
          await interaction.reply({ content: '❌ Only server administrators can use this command.', ephemeral: true });
          return;
        }
        if (interaction.options.getSubcommand() === 'set-coaches-channel') {
          const channel = interaction.options.getChannel('channel');
          saveGuildSetting(interaction.guild.id, 'coachesChannelId', channel.id);
          await interaction.reply({ content: `✅ Coaches channel set to <#${channel.id}> for this server.`, ephemeral: true });
          return;
        }
      }
    }
    // --- SELECT MENU ---
    if (interaction.isStringSelectMenu && interaction.customId === EVENT_SELECT_TIME) {
      const choice = interaction.values[0];
      const temp = eventRSVPs[interaction.user.id];
      if (!temp) return;
      let whenString = '';
      if (choice === 'in 1 hour') whenString = 'in 1 hour';
      if (choice === 'tonight') whenString = `today 19:00`;
      if (choice === 'tomorrow') whenString = `tomorrow 18:00`;
      if (choice === 'in a week') whenString = 'in a week';
      if (choice === 'custom') {
        // Show modal for custom date and time, vertical layout
        const modal = new ModalBuilder()
          .setCustomId(EVENT_MODAL_DATE_TIME)
          .setTitle('Event Date & Time')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('event_date_input')
                .setLabel('Date (YYYY-MM-DD)')
                .setPlaceholder('e.g. 2025-07-18')
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('event_time_input')
                .setLabel('Time (HH:mm, 24h)')
                .setPlaceholder('e.g. 14:00')
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );
        await interaction.showModal(modal);
        return;
      }
      // Parse and continue event creation
      await handleEventTime(interaction, whenString, temp.title, temp.desc);
      delete eventRSVPs[interaction.user.id];
      return;
    }
    // --- MODAL FOR CUSTOM DATE & TIME ---
    if (interaction.isModalSubmit() && interaction.customId === EVENT_MODAL_DATE_TIME) {
      const temp = eventRSVPs[interaction.user.id];
      if (!temp) return;
      const dateStr = interaction.fields.getTextInputValue('event_date_input');
      const timeStr = interaction.fields.getTextInputValue('event_time_input');
      const whenString = `${dateStr} ${timeStr}`;
      await handleEventTime(interaction, whenString, temp.title, temp.desc);
      delete eventRSVPs[interaction.user.id];
      return;
    }
    // --- BUTTONS ---
    if (interaction.isButton()) {
      // Find the event message
      const message = interaction.message;
      const event = eventRSVPs[message.id];
      if (!event) return;
      // Remove user from all RSVP lists first
      event.going.delete(interaction.user.id);
      event.maybe.delete(interaction.user.id);
      event.cant.delete(interaction.user.id);
      if (interaction.customId === EVENT_BUTTONS.GOING) {
        event.going.add(interaction.user.id);
        await updateEventEmbed(message, event, interaction.client);
        await interaction.reply({ content: '✅ You are going! Your RSVP has been recorded.', ephemeral: true });
        return;
      }
      if (interaction.customId === EVENT_BUTTONS.MAYBE) {
        event.maybe.add(interaction.user.id);
        await updateEventEmbed(message, event, interaction.client);
        await interaction.reply({ content: '🤔 You marked as maybe. Your RSVP has been recorded.', ephemeral: true });
        return;
      }
      if (interaction.customId === EVENT_BUTTONS.CANT) {
        // Show modal for reason
        const modal = new ModalBuilder()
          .setCustomId(`${EVENT_MODAL.CANT_REASON}:${message.id}`)
          .setTitle("Can't Attend Reason")
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId(EVENT_MODAL.CANT_REASON_INPUT)
                .setLabel('Why can\'t you attend?')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            )
          );
        await interaction.showModal(modal);
        return;
      }
    }
    // --- MODALS ---
    if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith(EVENT_MODAL.CANT_REASON)) {
        const messageId = interaction.customId.split(':')[1];
        const event = eventRSVPs[messageId];
        if (!event) return;
        const reason = interaction.fields.getTextInputValue(EVENT_MODAL.CANT_REASON_INPUT);
        // Remove user from other lists
        event.going.delete(interaction.user.id);
        event.maybe.delete(interaction.user.id);
        event.cant.set(interaction.user.id, reason);
        // Update event embed
        const channel = interaction.channel;
        const msg = await channel.messages.fetch(messageId);
        await updateEventEmbed(msg, event, interaction.client);
        await interaction.reply({ content: '❌ Your reason has been sent to the coaches.', ephemeral: true });
        // Send improved embed to coaches
        const channelId = getGuildSetting(interaction.guild.id, 'coachesChannelId');
        if (channelId) {
          const coachesChannel = interaction.client.channels.cache.get(channelId);
          if (coachesChannel) {
            const coachEmbed = new EmbedBuilder()
              .setColor('#ff0000')
              .setTitle('❌ RSVP: Not Attending')
              .setDescription(`<@${interaction.user.id}> cannot attend the event.`)
              .addFields(
                { name: 'Event', value: event.title, inline: false },
                { name: 'When', value: event.when, inline: false },
                { name: 'Reason', value: reason, inline: false }
              )
              .setTimestamp();
            coachesChannel.send({ embeds: [coachEmbed] });
          }
        }
        return;
      }
    }
  } catch (error) {
    console.error('Interaction error:', error);
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ content: 'An error occurred. Please try again later.' }).catch(() => {});
    } else {
      await interaction.reply({ content: 'An error occurred. Please try again later.', ephemeral: true }).catch(() => {});
    }
  }
});

/**
 * Calculate the player value based on their stats
 * @param {Object} stats - The player's stats
 * @returns {number} - The calculated player value
 */
function calculatePlayerValue(stats) {
  let totalValue = 0;

  // Calculate the value for each stat
  for (const [stat, value] of Object.entries(stats)) {
    totalValue += value * STAT_WEIGHTS[stat];
  }

  return totalValue;
}

/**
 * Determine the player type based on their stat contributions
 * @param {Object} statContributions - The contribution of each stat to the total value
 * @returns {string} - The player type description
 */
function getPlayerType(statContributions) {
  // Group stats by category
  const defensiveContribution = statContributions.tackles + statContributions.inters + statContributions.saves;
  const offensiveContribution = statContributions.goals + statContributions.shots + statContributions.dribbles;
  const playmakerContribution = statContributions.assists + statContributions.passes;
  const experienceContribution = statContributions.games;
  
  const totalContribution = defensiveContribution + offensiveContribution + playmakerContribution + experienceContribution;
  
  // Calculate percentages
  const defensivePercentage = (defensiveContribution / totalContribution) * 100;
  const offensivePercentage = (offensiveContribution / totalContribution) * 100;
  const playmakerPercentage = (playmakerContribution / totalContribution) * 100;
  
  // Determine primary player type
  if (defensivePercentage > 50) {
    return '🛡️ Defensive Specialist';
  } else if (offensivePercentage > 50) {
    return '⚽ Offensive Powerhouse';
  } else if (playmakerPercentage > 50) {
    return '🔄 Elite Playmaker';
  } else if (defensivePercentage >= 33 && offensivePercentage >= 33) {
    return '⚖️ Two-Way Player';
  } else if (defensivePercentage >= 33 && playmakerPercentage >= 33) {
    return '🧠 Defensive Playmaker';
  } else if (offensivePercentage >= 33 && playmakerPercentage >= 33) {
    return '🎯 Creative Attacker';
  } else {
    return '🌟 Complete Player';
  }
}

/**
 * Format a stat name to be more readable
 * @param {string} stat - The stat name
 * @returns {string} - The formatted stat name
 */
function formatStatName(stat) {
  const statIcons = {
    tackles: '🛡️ Tackles',
    inters: '🔒 Interceptions',
    saves: '🧤 Saves',
    goals: '⚽ Goals',
    shots: '🎯 Shots',
    dribbles: '👟 Dribbles',
    assists: '🅰️ Assists',
    passes: '🔄 Passes',
    games: '🏟️ Games'
  };
  
  return statIcons[stat] || stat.charAt(0).toUpperCase() + stat.slice(1);
}

// Helper to update the event embed with RSVP lists
async function updateEventEmbed(message, event, client) {
  const goingList = event.going.size ? Array.from(event.going).map(id => `<@${id}>`).join(' | ') : 'No one yet';
  const maybeList = event.maybe.size ? Array.from(event.maybe).map(id => `<@${id}>`).join(' | ') : 'No one yet';
  const cantList = event.cant.size ? Array.from(event.cant.keys()).map(id => `<@${id}>`).join(' | ') : 'No one yet';
  const links = [
    event.scheduledEventUrl ? `[🔗 Event](${event.scheduledEventUrl})` : null,
    event.gcalLink ? `[📅 Calendar](${event.gcalLink})` : null
  ].filter(Boolean).join(' ');
  const embed = new EmbedBuilder()
    .setColor('#00b0f4')
    .setTitle(`📅 **${event.title.toUpperCase()}**`);
  if (event.desc) embed.setDescription(`_${event.desc}_`);
  embed.addFields(
    { name: 'Time', value: event.when, inline: true },
    { name: 'Duration', value: `${event.durationHours || 2} hours`, inline: true },
    { name: '\u200B', value: '\u200B', inline: true }, // Spacer
    { name: `✅ Attendees (${event.going.size})`, value: goingList, inline: true },
    { name: `🤔 Maybe (${event.maybe.size})`, value: maybeList, inline: true },
    { name: `❌ No (${event.cant.size})`, value: cantList, inline: true },
    { name: 'Links', value: links, inline: false }
  );
  embed.setFooter({ text: `Created by ${event.username || (event.creator ? (client.users.cache.get(event.creator)?.username || 'Unknown') : 'Unknown')}` });
  await message.edit({ embeds: [embed] });
}

// Helper to handle event creation after time selection
async function handleEventTime(interaction, whenString, title, desc) {
  const results = chrono.parse(whenString, new Date(), { forwardDate: true });
  if (!results.length) {
    await interaction.reply({ content: '❌ Could not understand the date/time. Please try again with a format like "2024-06-10 18:00", "next Friday at 7pm", or "in 2 days".', ephemeral: true });
    return;
  }
  const timestamp = results[0].start.date();
  if (timestamp.getTime() < Date.now()) {
    await interaction.reply({ content: '❌ The event time must be in the future. Please provide a valid future date/time.', ephemeral: true });
    return;
  }
  const discordTimestamp = `<t:${Math.floor(timestamp.getTime() / 1000)}:F>`;
  const startTime = timestamp;
  const endTime = new Date(timestamp.getTime() + 2 * 60 * 60 * 1000); // Default 2h event
  const durationHours = Math.round((endTime - startTime) / (1000 * 60 * 60));
  // Create Discord Scheduled Event
  let scheduledEvent = null;
  try {
    scheduledEvent = await interaction.guild.scheduledEvents.create({
      name: title,
      scheduledStartTime: startTime,
      scheduledEndTime: endTime,
      privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
      entityType: GuildScheduledEventEntityType.External,
      description: desc,
      entityMetadata: { location: 'TBA' }
    });
  } catch (e) {
    console.error('Failed to create scheduled event:', e);
  }
  // Google Calendar link
  const gcalLink = googleCalendarLink({ title, description: desc, start: startTime, end: endTime });
  // Minimal, wide event embed styled like the example
  const links = [
    scheduledEvent ? `[🔗 Event](${scheduledEvent.url})` : null,
    `[📅 Calendar](${gcalLink})`
  ].filter(Boolean).join(' ');
  const embed = new EmbedBuilder()
    .setColor('#00b0f4')
    .setTitle(`📅 **${title.toUpperCase()}**`);
  if (desc) embed.setDescription(`_${desc}_`);
  embed.addFields(
    { name: 'Time', value: discordTimestamp, inline: true },
    { name: 'Duration', value: `${durationHours} hours`, inline: true },
    { name: '\u200B', value: '\u200B', inline: true }, // Spacer
    { name: `✅ Attendees (0)`, value: 'No one yet', inline: true },
    { name: `🤔 Maybe (0)`, value: 'No one yet', inline: true },
    { name: `❌ No (0)`, value: 'No one yet', inline: true },
    { name: 'Links', value: links, inline: false }
  );
  embed.setFooter({ text: `Created by ${interaction.user.username}` });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(EVENT_BUTTONS.GOING)
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(EVENT_BUTTONS.MAYBE)
      .setEmoji('🤔')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(EVENT_BUTTONS.CANT)
      .setEmoji('❌')
      .setStyle(ButtonStyle.Danger)
  );
  const reply = await interaction.channel.send({ embeds: [embed], components: [row] });
  // Initialize RSVP state
  eventRSVPs[reply.id] = { going: new Set(), maybe: new Set(), cant: new Map(), title, when: discordTimestamp, creator: interaction.user.id, desc, scheduledEventUrl: scheduledEvent?.url, gcalLink, durationHours, username: interaction.user.username };
  // Always reply to the modal interaction with a confirmation
  if (interaction.isRepliable && !interaction.replied && !interaction.deferred) {
    await interaction.reply({ content: '✅ Event created and posted in this channel!', ephemeral: true });
  }
}

// Login to Discord with your token
client.login(process.env.DISCORD_TOKEN);